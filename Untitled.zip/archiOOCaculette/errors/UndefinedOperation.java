package errors;

public class UndefinedOperation extends Throwable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
